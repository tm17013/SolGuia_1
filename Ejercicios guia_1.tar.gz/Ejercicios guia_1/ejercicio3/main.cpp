#include <iostream>
#include <math.h>
/* Tepas Mazariego, Kenia Stephannie  tm17013*/
int main()

{

    /*variables*/
    double media_arit, desv, var;
    float dev_estandar;
    double suma0,suma1;
    int n;

  /*vector, n*/
    printf("Ingrese el numero total de datos a ingresar o tamaño del vector: \n");
    scanf("%i", &n);
    double vector[n];

   /*Ingreso de datos*/
    for (int i = 0; i < n; ++i) {
        printf("Ingrese los datos %i%s", i + 1, ": ");
        scanf("%lf", &vector[i]);
        suma0 = suma0 + vector[i];
    }
   /*calculo media usando pow*/
    media_arit= suma0 / n;

    for (int s = 0; s < n; ++s){
        suma1 = suma1 + pow((vector[s] - media_arit), 2);
    }

    /*calculo varianza usando sqrt*/
    var = suma1/n;
    desv = sqrt(var);

    /*Resultado datos ingresados*/
    printf("\n Los datos ingresados:  \n");
    for(int w = 0; w<n ; ++w){
        printf("\n %lf%s", vector[w]," "" ");
    }
    /*Mostrar media, deviacion, varianza */
    printf("\n");
    printf("La media es %lf", media_arit);
    printf("\n");
    printf("La varianza es %lf", var);
    printf("\n");
    printf("La desviacion tipica es %lf", desv);
   return 0;
}