#include <iostream>

int main() {
    /* std::cout << "Hello, World!" << std::endl;*/
    int n;
    int pos;
    printf("Ingrese tamaño del vector: \n");
    scanf("%d", &n);
    int vector[n];
    printf("Ingrese datos del vector: \n");
    for (int j = 0; j < n; ++j) {
        scanf("%i",&vector[j]);
    }
    printf("Ingrese posicion a eliminar del vector: \n");
    scanf("%i", &pos);
    int eliminado;
    if (pos > n) {
        std::cout << "ESTA POSICION NO EXISTE" << std::endl;
        for (int x = 0; x < n; ++x) {
            std::cout << "El elemento en la posicion " << x << " del arreglo es: " << vector[x] << std::endl;
        }
    } else{
        eliminado=vector[pos];
        for (int x = 0; x < n; ++x) {
            if (x==pos){
                while(x<n){
                    vector[x]=vector[x+1];
                    x++;
                }break;
            }

        }
        n=n-1;
        std::cout << "Resultado: " << std::endl;
        for (int x = 0; x < n; ++x) {
            std::cout << "El elemento en la posicion " << x << " del arreglo es: " << vector[x] << std::endl;
        }
}
    return 0;
}