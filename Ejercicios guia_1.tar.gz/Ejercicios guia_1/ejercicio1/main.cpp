#include <iostream>

int main() {

    int n,n1;

    printf("Ingrese tamaño del vector \n");
    scanf("%d",&n);
    int vector[n];
    printf("Ingrese datos del vector \n");
    for (int j = 0; j < n; ++j) {
        scanf("%i", &vector[j]);
    }

    printf("Ingrese tamaño del vector a copiar\n");
    scanf("%d",&n1);
    int vector0[n1];
    printf("Ingrese datos del vector a copiar \n");
    for (int j = 0; j < n1; ++j) {
        scanf("%i", &vector0[j]);
    }
    int n2= n+n1;
    int vector1[n2];
    for(int h=0;h<n;h++){
        vector1[h]=vector[h];
    }
    for(int h=n;h<n2;h++){
        vector1[h]=vector0[h-n];
    }
    std::cout << "Resultado vector en el otro vector:  " << std::endl;
    for(int h=0;h<n2;h++) {
        std::cout << vector1[h] << std::endl;
    }
    return 0;
}